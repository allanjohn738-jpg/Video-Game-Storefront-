from flask import Flask, render_template

app = Flask(__name__)

@app.route('/home') 
def hello():
    return render_template('index.html',message="Hello world!")

if __name__ == '__main__':
    app.run()
