from flask import Flask, render_template, request, redirect, session, url_for, flash
from flask_wtf import FlaskForm
from wtforms import IntegerField, SubmitField, StringField, PasswordField, TextAreaField
from wtforms.validators import DataRequired, NumberRange, Length, EqualTo, Regexp
from flask_bootstrap import Bootstrap
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from decimal import Decimal
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
bootstrap = Bootstrap(app)
app.config['SECRET_KEY'] = "top secret password don't tell anyone this"

# Configure database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///basket.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"  # Redirects the user to an appropriate route if not logged in
login_manager.login_message = "Please log in to access this page."

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# BasketItem model
class BasketItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False) 
    game_id = db.Column(db.Integer, nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    added_at = db.Column(db.DateTime, default=datetime.utcnow)

games = [
    {
        "id": 0,
        "name": "Minecraft Standard Pack",
        "slug": "minecraft-standard-pack",
        "price": Decimal("29.99"),
        "image": "Minecraft.webp",
        "description": "Step into a limitless sandbox where your imagination sets the rules. Minecraft Standard Pack gives you complete creative freedom from building intricate cities block by block to surviving hostile nights filled with creepers and skeletons. With powerful mod support and endless community-created content, this version is the ultimate playground for players who want to customise, experiment, and truly make the world their own. Minecraft Standard Pack is available as CD compatible with all devices.",
        "environmental_impact": "The packaging for this product is made from sustainably sourced plastic and the disc itself is manufactured using a reduced emission process. Physical CDs have a lower long-term carbon footprint than repeated digital downloads, and the disc casing is produced using partially recycled plastics. We encourage customers to recycle discs responsibly once finished. We replenish our stock from retailers that follow enviromental standards under the ISO 14001 environmental management standard, as well as from those that comply with the UK and European Union environmental regulations."
    },
    {
        "id": 1,
        "name": "Minecraft Deluxe Pack",
        "slug": "minecraft-deluxe-pack",
        "price": Decimal("39.99"),
        "image": "Minecraft.webp",
        "description": "The Minecraft Deluxe Pack enhances the classic block-building experience with bonus content designed to personalise your adventure. Explore vast, procedurally generated worlds while expressing your style through exclusive skins, texture packs, and creative add-ons. Whether you’re constructing massive castles or teaming up with friends, this bundle adds flair and extra variety to your journey. Minecraft Deluxe Pack is available as CD compatible with all devices.",
        "environmental_impact": "The packaging for this product is made from sustainably sourced plastic and the disc itself is manufactured using a reduced emission process. Physical CDs have a lower long-term carbon footprint than repeated digital downloads, and the disc casing is produced using partially recycled plastics. We encourage customers to recycle discs responsibly once finished. We replenish our stock from retailers that follow enviromental standards under the ISO 14001 environmental management standard, as well as from those that comply with the UK and European Union environmental regulations."
    },
    {
        "id": 2,
        "name": "Elden Ring",
        "slug": "elden-ring",
        "price": Decimal("49.99"),
        "image": "Elden.webp",
        "description": "A hauntingly beautiful world stretches before you in this dark fantasy epic. Crafted with intricate lore and punishing yet rewarding combat, Elden Ring challenges you to explore vast open landscapes filled with towering castles, hidden secrets, and formidable foes. Every victory feels earned, every discovery meaningful, and every step forward pushes you deeper into a mysterious and shattered realm. Elden Ring is available as CD compatible with all devices.",
        "environmental_impact": "The packaging for this product is made from sustainably sourced plastic and the disc itself is manufactured using a reduced emission process. Physical CDs have a lower long-term carbon footprint than repeated digital downloads, and the disc casing is produced using partially recycled plastics. We encourage customers to recycle discs responsibly once finished. We replenish our stock from retailers that follow enviromental standards under the ISO 14001 environmental management standard, as well as from those that comply with the UK and European Union environmental regulations."
    },
    {
        "id": 3,
        "name": "Call of Duty: Modern Warfare",
        "slug": "call-of-duty-modern-warfare",
        "price": Decimal("40.99"),
        "image": "cod.avif",
        "description": "Experience high-stakes tactical combat in a gritty, cinematic shooter that blends realism with intense action. From tightly coordinated special operations to fast-paced multiplayer firefights, Modern Warfare delivers adrenaline-fuelled encounters across global battlegrounds. Precision, teamwork, and quick thinking are the keys to survival in this grounded military thriller. Call of Duty: Modern Warfare is available as CD compatible with all devices.",
        "environmental_impact": "The packaging for this product is made from sustainably sourced plastic and the disc itself is manufactured using a reduced emission process. Physical CDs have a lower long-term carbon footprint than repeated digital downloads, and the disc casing is produced using partially recycled plastics. We encourage customers to recycle discs responsibly once finished. We replenish our stock from retailers that follow enviromental standards under the ISO 14001 environmental management standard, as well as from those that comply with the UK and European Union environmental regulations."
    },
    {
        "id": 4,
        "name": "Far Cry 6",
        "slug": "far-cry-6",
        "price": Decimal("45.99"),
        "image": "farcry6.jpg",
        "description": "Welcome to a tropical island on the brink of revolution. In Far Cry 6, you step into the role of a guerrilla fighter battling a powerful regime across jungles, cities, and coastlines. With improvised weapons, customisable gear, and unpredictable encounters, every mission blends explosive action with open-world freedom. Far Cry 6 is available as CD compatible with all devices.",
        "environmental_impact": "The packaging for this product is made from sustainably sourced plastic and the disc itself is manufactured using a reduced emission process. Physical CDs have a lower long-term carbon footprint than repeated digital downloads, and the disc casing is produced using partially recycled plastics. We encourage customers to recycle discs responsibly once finished. We replenish our stock from retailers that follow enviromental standards under the ISO 14001 environmental management standard, as well as from those that comply with the UK and European Union environmental regulations."
    },
    {
        "id": 5,
        "name": "Grand Theft Auto V",
        "slug": "grand-theft-auto-v",
        "price": Decimal("49.99"),
        "image": "gta5.png",
        "description": "Enter a sprawling, satirical recreation of modern America where crime, ambition, and chaos collide. Grand Theft Auto V weaves together the lives of three distinct characters in a high-stakes story filled with daring heists, fast cars, and unpredictable twists. Beyond the narrative, the massive open world invites you to explore, compete, and create your own stories in a city that never sleeps. Grand Theft Auto V is available as CD compatible with all devices.",
        "environmental_impact": "The packaging for this product is made from sustainably sourced plastic and the disc itself is manufactured using a reduced emission process. Physical CDs have a lower long-term carbon footprint than repeated digital downloads, and the disc casing is produced using partially recycled plastics. We encourage customers to recycle discs responsibly once finished. We replenish our stock from retailers that follow enviromental standards under the ISO 14001 environmental management standard, as well as from those that comply with the UK and European Union environmental regulations."
    }
]

class QuantityForm(FlaskForm):
    quantity = IntegerField('Quantity: ',validators = [DataRequired(),NumberRange(min=0,max=10)])
    submit = SubmitField('Submit')


@app.route('/')
def galleryPage():
    sort = request.args.get('sort', 'default')

    sorted_games = games.copy()

    if sort == 'name_asc':
        sorted_games = sorted(sorted_games, key=lambda x: x['name'])
    elif sort == 'name_desc':
        sorted_games = sorted(sorted_games, key=lambda x: x['name'], reverse=True)
    elif sort == 'price_asc':
        sorted_games = sorted(sorted_games, key=lambda x: x['price'])
    elif sort == 'price_desc':
        sorted_games = sorted(sorted_games, key=lambda x: x['price'], reverse=True)

    return render_template('index.html', games=sorted_games, sort=sort)


@app.route('/game/<slug>', methods=['GET', 'POST'])
def singleProductPage(slug):
    # Identifies games by using slug
    game = next((g for g in games if g['slug'] == slug), None)

    if game is None:
        flash("Game not found.")
        return redirect(url_for("galleryPage"))
    
    form = QuantityForm()
    if form.validate_on_submit():
        return render_template('SingleTechOpinion.html', game=game, quantity=form.quantity.data)
    else:
        return render_template('SingleTech.html', game=game, form=form)
    
    
class RegisterForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=20)])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    confirm = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password', message='Passwords must match')])
    submit = SubmitField('Register')

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')


@app.route("/register", methods=["GET", "POST"])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        # Check if username already registered
        existing_user = User.query.filter_by(username=form.username.data).first()
        if existing_user:
            flash("That username is already taken. Please choose a different one.")
            return redirect(url_for("register"))
        
        # Hash the password before storing it
        hashed_pw = generate_password_hash(form.password.data)
        new_user = User(
            username=form.username.data,
            password=hashed_pw
        )
        db.session.add(new_user)
        db.session.commit()
        flash("Account created successfully! Please log in.")
        return redirect(url_for("login"))
    
    return render_template("register.html", form=form)


@app.route("/login", methods=["GET", "POST"])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        # Look up user by username
        user = User.query.filter_by(username=form.username.data).first()
        # Check user exists and password matches the stored hash
        if user and check_password_hash(user.password, form.password.data):
            login_user(user)
            flash(f"Welcome back, {user.username}!")
            return redirect(url_for("galleryPage"))
        flash("Invalid username or password. Please try again.")
    
    return render_template("login.html", form=form)


@app.route("/logout")
@login_required
def logout():
    logout_user()
    flash("You have been logged out successfully.")
    return redirect(url_for("galleryPage"))


@app.route("/add_to_basket", methods=["POST"])
def add_to_basket():  
    game_id = int(request.form.get("game_id"))
    quantity = int(request.form.get("quantity"))

    if current_user.is_authenticated:
        existing_item = BasketItem.query.filter_by(
            game_id=game_id,
            user_id=current_user.id
        ).first()
        if existing_item:
            new_quantity = existing_item.quantity + quantity
            if new_quantity > 10:
                flash(f"You can only have a maximum of 10 of each item in your basket.")
                return redirect(url_for("singleProductPage", gamesId=game_id))
            existing_item.quantity = new_quantity
        else:
            if quantity > 10:
                flash("You can only add a maximum of 10 of each item.")
                return redirect(url_for("singleProductPage", gamesId=game_id))
            new_item = BasketItem(game_id=game_id, quantity=quantity, user_id=current_user.id)
            db.session.add(new_item)
        db.session.commit()
    else:
        basket = session.get("guest_basket", {})
        game_id_str = str(game_id)
        current_quantity = basket.get(game_id_str, 0)
        new_quantity = current_quantity + quantity
        if new_quantity > 10:
            flash("You can only have a maximum of 10 of each item in your basket.")
            return redirect(url_for("singleProductPage", gamesId=game_id))
        basket[game_id_str] = new_quantity
        session["guest_basket"] = basket

    flash(f"{games[game_id]['name']} (x{quantity}) added to basket!")
    return redirect(url_for("singleProductPage", slug=games[game_id]['slug']))


@app.route("/basket")
def view_basket():
    basket_contents = []
    total_price = Decimal("0")

    if current_user.is_authenticated:
        # Logged in to view basket, stores and merges guest selected items with logged in user once logged in.
        items = BasketItem.query.filter_by(user_id=current_user.id).all()
        for item in items:
            game = games[item.game_id]
            subtotal = game["price"] * item.quantity
            basket_contents.append({
                "game_id": item.game_id,       
                "name": game["name"],
                "price": game["price"],
                "quantity": item.quantity,
                "subtotal": subtotal
            })
            total_price += subtotal
    else:
        # Loads from session, for guest users
        guest_basket = session.get("guest_basket", {})
        for game_id_str, quantity in guest_basket.items():
            game = games[int(game_id_str)]
            subtotal = game["price"] * quantity
            basket_contents.append({
                "game_id": int(game_id_str),   
                "name": game["name"],
                "price": game["price"],
                "quantity": quantity,
                "subtotal": subtotal
            })
            total_price += subtotal

    return render_template("basket.html", basket=basket_contents, total=total_price)


@app.route("/update_basket", methods=["POST"])
def update_basket():
    game_id = int(request.form.get("game_id"))
    action = request.form.get("action")

    if current_user.is_authenticated:
        item = BasketItem.query.filter_by(game_id=game_id, user_id=current_user.id).first()
        if item:
            if action == "increase":
                if item.quantity >= 10:
                    flash("You can only have a maximum of 10 of each item in your basket.")
                    return redirect(url_for("view_basket"))
                item.quantity += 1
            elif action == "decrease":
                if item.quantity > 1:
                    item.quantity -= 1
                else:
                    db.session.delete(item)
            db.session.commit()
    else:
        basket = session.get("guest_basket", {})
        game_id_str = str(game_id)
        if game_id_str in basket:
            if action == "increase":
                if basket[game_id_str] >= 10:
                    flash("You can only have a maximum of 10 of each item in your basket.")
                    return redirect(url_for("view_basket"))
                basket[game_id_str] += 1
            elif action == "decrease":
                if basket[game_id_str] > 1:
                    basket[game_id_str] -= 1
                else:
                    del basket[game_id_str]
        session["guest_basket"] = basket

    return redirect(url_for("view_basket"))


@app.route("/remove_from_basket", methods=["POST"])
def remove_from_basket():
    game_id = int(request.form.get("game_id"))

    if current_user.is_authenticated:
        item = BasketItem.query.filter_by(game_id=game_id, user_id=current_user.id).first()
        if item:
            db.session.delete(item)
            db.session.commit()
    else:
        basket = session.get("guest_basket", {})
        game_id_str = str(game_id)
        if game_id_str in basket:
            del basket[game_id_str]
        session["guest_basket"] = basket

    flash("Item removed from basket.")
    return redirect(url_for("view_basket"))


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)


class CheckoutForm(FlaskForm):
    full_name = StringField('Full Name', validators=[DataRequired(), Length(min=2, max=100)])
    address = TextAreaField('Delivery Address', validators=[DataRequired(), Length(min=5, max=300)])
    city = StringField('City', validators=[DataRequired(), Length(min=2, max=100)])
    postcode = StringField('Postcode', validators=[DataRequired(), Length(min=5, max=10)])
    card_number = StringField('Card Number', validators=[
        DataRequired(),
        Regexp(r'^\d{16}$', message='Card number must be exactly 16 digits')
    ])
    expiry = StringField('Expiry Date (MM/YY)', validators=[
        DataRequired(),
        Regexp(r'^(0[1-9]|1[0-2])\/\d{2}$', message='Expiry must be in MM/YY format')
    ])
    cvv = StringField('CVV', validators=[
        DataRequired(),
        Regexp(r'^\d{3}$', message='CVV must be exactly 3 digits')
    ])
    submit = SubmitField('Confirm Payment')


@app.route("/checkout_form", methods=["GET", "POST"])
@login_required
def checkout_form():
    form = CheckoutForm()

    # Imports basket contents to display on the checkout page
    items = BasketItem.query.filter_by(user_id=current_user.id).all()
    basket_contents = []
    total_price = Decimal("0")
    for item in items:
        game = games[item.game_id]
        subtotal = game["price"] * item.quantity
        basket_contents.append({
            "name": game["name"],
            "price": game["price"],
            "quantity": item.quantity,
            "subtotal": subtotal
        })
        total_price += subtotal

    if form.validate_on_submit():
        # Clear the basket on successful submission
        BasketItem.query.filter_by(user_id=current_user.id).delete()
        db.session.commit()
        flash(f"Payment successful! Thank you, {form.full_name.data}. Your order is confirmed.")
        return redirect(url_for("galleryPage"))

    return render_template("checkout.html", form=form, basket=basket_contents, total=total_price)


@app.route("/checkout", methods=["POST"])
@login_required
def checkout():
    return redirect(url_for("checkout_form"))


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)

